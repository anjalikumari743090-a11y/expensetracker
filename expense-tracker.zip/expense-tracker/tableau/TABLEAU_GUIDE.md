# Tableau Guide - Expense Tracker

## 1. Get the data
Run the app, upload a statement and click **Download Tableau-ready CSV** (`tableau_expenses.csv`).
Columns: Date, Description, Amount, Type, Category, Month, Year, Month Name, Day Of Week.

## 2. Connect
Tableau Public/Desktop -> **Connect -> Text File** -> select `tableau_expenses.csv`.
Check in Data Source tab: Date = Date, Amount = Number (decimal).

## 3. Build 5 worksheets (drag and drop)
1. **Spending by Category** (Bar): Columns = SUM(Amount), Rows = Category, sort descending, Color = Category.
2. **Monthly Trend** (Line): Columns = Date (right-click -> Month, continuous), Rows = SUM(Amount).
3. **Category Share** (Pie): Marks = Pie, Angle = SUM(Amount), Color = Category, Label = Category + % of Total.
4. **Top 10 Expenses** (Table): Rows = Description, Text = SUM(Amount). Description -> Filter -> Top -> By field -> Top 10 by SUM(Amount).
5. **Weekday Heatmap**: Columns = Day Of Week, Rows = Category, Marks = Square, Color = SUM(Amount).

## 4. Dashboard
**Dashboard -> New Dashboard** -> drag all 5 sheets -> add a **KPI sheet** (Text: SUM(Amount) = Total Spent).
Use sheets as filters (Use as Filter icon) so clicking a category updates all charts.

## 5. Notes
- Tableau Public workbooks are public. Do not publish real personal statements; use the sample data.
- Tableau does not auto-sync with new uploads; download a fresh CSV and refresh the data source (F5).
