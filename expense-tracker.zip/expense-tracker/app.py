"""Expense Tracker Dashboard - upload a bank/UPI statement CSV and analyze spending."""
import sqlite3
import pandas as pd
import plotly.express as px
import streamlit as st

DB = "expenses.db"
CATEGORY_KEYWORDS = {
    "Food": ["swiggy", "zomato", "restaurant", "cafe", "dominos", "mcdonald"],
    "Groceries": ["bigbasket", "blinkit", "zepto", "dmart", "grocery"],
    "Transport": ["uber", "ola", "metro", "fuel", "petrol", "irctc"],
    "Shopping": ["amazon", "flipkart", "myntra", "ajio"],
    "Bills": ["electricity", "recharge", "jio", "airtel", "wifi", "rent"],
    "Entertainment": ["netflix", "spotify", "bookmyshow", "hotstar"],
}


def categorize(description: str) -> str:
    text = str(description).lower()
    for category, words in CATEGORY_KEYWORDS.items():
        if any(w in text for w in words):
            return category
    return "Other"


def load_data(file) -> pd.DataFrame:
    df = pd.read_csv(file)
    df.columns = [c.strip().title() for c in df.columns]
    df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, errors="coerce")
    df["Amount"] = pd.to_numeric(df["Amount"], errors="coerce")
    df = df.dropna(subset=["Date", "Amount"])
    if "Type" in df.columns:
        df = df[df["Type"].str.lower() == "debit"]
    df["Category"] = df["Description"].apply(categorize)
    df["Month"] = df["Date"].dt.to_period("M").astype(str)
    df["Year"] = df["Date"].dt.year
    df["Month Name"] = df["Date"].dt.strftime("%b")
    df["Day Of Week"] = df["Date"].dt.day_name()
    return df


def save_history(df: pd.DataFrame) -> None:
    with sqlite3.connect(DB) as conn:
        df.assign(Date=df["Date"].astype(str)).to_sql("expenses", conn, if_exists="replace", index=False)


def read_history() -> pd.DataFrame:
    try:
        with sqlite3.connect(DB) as conn:
            return pd.read_sql("SELECT * FROM expenses", conn, parse_dates=["Date"])
    except Exception:
        return pd.DataFrame()


st.set_page_config(page_title="Expense Tracker", page_icon="💸", layout="wide")
st.title("💸 Expense Tracker Dashboard")
st.caption("CSV columns required: Date, Description, Amount (optional: Type = Debit/Credit)")

uploaded = st.file_uploader("Upload your statement CSV", type="csv")
if uploaded:
    data = load_data(uploaded)
    if st.button("Save to history (SQLite)"):
        save_history(data)
        st.success("Saved!")
elif st.checkbox("Load last saved history"):
    data = read_history()
else:
    data = pd.DataFrame()

if data.empty:
    st.info("Upload a CSV (try sample_expenses.csv) to see the dashboard.")
    st.stop()

categories = st.sidebar.multiselect("Categories", sorted(data["Category"].unique()),
                                    default=sorted(data["Category"].unique()))
data = data[data["Category"].isin(categories)]

c1, c2, c3 = st.columns(3)
c1.metric("Total Spent", f"₹{data['Amount'].sum():,.0f}")
c2.metric("Transactions", len(data))
c3.metric("Avg per Transaction", f"₹{data['Amount'].mean():,.0f}")

left, right = st.columns(2)
by_cat = data.groupby("Category", as_index=False)["Amount"].sum()
left.plotly_chart(px.pie(by_cat, names="Category", values="Amount", hole=0.4,
                         title="Spending by Category"), use_container_width=True)
by_month = data.groupby("Month", as_index=False)["Amount"].sum()
right.plotly_chart(px.line(by_month, x="Month", y="Amount", markers=True,
                           title="Monthly Trend"), use_container_width=True)

st.subheader("Top 10 Expenses")
st.dataframe(data.nlargest(10, "Amount")[["Date", "Description", "Category", "Amount"]],
             use_container_width=True)
d1, d2 = st.columns(2)
d1.download_button("Download categorized CSV", data.to_csv(index=False), "categorized_expenses.csv")
d2.download_button("Download Tableau-ready CSV", data.to_csv(index=False, date_format="%Y-%m-%d"),
                   "tableau_expenses.csv", help="Connect this file in Tableau via Text File")
