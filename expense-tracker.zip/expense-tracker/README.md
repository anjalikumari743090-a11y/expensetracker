# Expense Tracker Dashboard
Streamlit + Pandas + Plotly + SQLite mini project.

## Run (Windows, VS Code)
```
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```
Upload `sample_expenses.csv` or your own statement (columns: Date, Description, Amount, optional Type).
Edit `CATEGORY_KEYWORDS` in `app.py` to add your own categories.

## Tableau
Click **Download Tableau-ready CSV** in the app, then follow `tableau/TABLEAU_GUIDE.md`.
